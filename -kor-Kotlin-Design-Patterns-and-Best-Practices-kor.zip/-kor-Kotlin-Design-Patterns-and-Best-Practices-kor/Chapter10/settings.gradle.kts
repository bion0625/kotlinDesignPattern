
rootProject.name = "CatsHostel"

