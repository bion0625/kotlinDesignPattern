fun main() {
    with(JamesBond()) {
        name = "Pierce Brosnan"

        println(this.name)
    }
}