fun main() {
    println(Spock.SENSE_OF_HUMOR)
}

class Spock {
    companion object {
        val SENSE_OF_HUMOR = "None"
    }
}

