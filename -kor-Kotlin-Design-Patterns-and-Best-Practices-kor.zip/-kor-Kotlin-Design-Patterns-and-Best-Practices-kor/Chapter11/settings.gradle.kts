
rootProject.name = "CatsShelterVertx"

