fun main() {
    val greeting = "Hi"

    // 동작하지 않습니다
    // greeting = "Bye" // val 은 재할당 될 수 없습니다
}