/*
 * 블록 주석입니다
 */
fun main() {
    // 일반적인 주석입니다
    println("Hello Kotlin")
}