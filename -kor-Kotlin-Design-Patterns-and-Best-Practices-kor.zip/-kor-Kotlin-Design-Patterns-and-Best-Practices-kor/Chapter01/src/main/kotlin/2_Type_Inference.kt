fun main() {
    var greeting = "Hello Kotlin"

    // 타입 명시:
    // var greeting: String = "Hello Kotlin"
    println(greeting)

    // 코틀린은 타입 언어이기 때문에 동작하지 않습니다
    // greeting = 1 // 정수 리터럴은 예상 타입인 문자열과 맞지 않습니다
}