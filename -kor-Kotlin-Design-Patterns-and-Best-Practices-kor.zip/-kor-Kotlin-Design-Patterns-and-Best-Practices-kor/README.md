# 도서 `코틀린 디자인 패턴 2/e` 예제 코드 한국어 버전

도서 `코틀린 디자인 패턴 2/e` 예제 코드를 한국어 설명으로 변경하였습니다

[원본 예제 레포↗](https://github.com/PacktPublishing/Kotlin-Design-Patterns-and-Best-Practices) ️

## 현황

- [x] Chapter01
- [ ] Chapter02
- [ ] Chapter03
- [ ] Chapter04
- [ ] Chapter05
- [ ] Chapter06
- [ ] Chapter07
- [ ] Chapter08
- [ ] Chapter09
- [ ] Chapter10
- [ ] Chapter11